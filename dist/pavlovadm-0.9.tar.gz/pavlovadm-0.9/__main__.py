import pavlovadm
pavlovadm.main()
