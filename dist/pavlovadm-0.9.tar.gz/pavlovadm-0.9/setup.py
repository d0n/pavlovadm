#!/usr/bin/env python

from distutils.core import setup
import setuptools


import __pkginfo__

pkginfo = {}
for i in dir(__pkginfo__):
	if i.startswith('__'): continue
	pkginfo[i] = getattr(__pkginfo__, i)

setup(**pkginfo)
