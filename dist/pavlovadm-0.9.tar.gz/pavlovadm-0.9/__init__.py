from pavlovadm.pavlovadm import main

def pavlovadm():
	"""pwclip passcrypt gui mode"""
	main()
