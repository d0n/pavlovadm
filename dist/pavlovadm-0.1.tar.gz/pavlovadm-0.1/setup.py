#!/usr/bin/env python

from distutils.core import setup

setup(name='pavlovadm',
      version='0.1',
      description='utility to manage pavlov\'s rcon like admin interface',
      author='d0n',
      author_email='d0n@janeiskla.de',
      url='https://www.python.org/d0n/pavlovadm/',
      packages=[],
     )
