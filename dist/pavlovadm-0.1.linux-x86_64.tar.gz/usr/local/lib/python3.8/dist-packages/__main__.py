import pavlovadm
pavlovadm.cli()
